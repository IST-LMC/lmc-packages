//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.Rc
//
#define IDS_HELPFILE                    1
#define IDS_SNAPINDESC                  2
#define IDS_NAME                        3
#define IDS_THIS_WEB_INSTANCE           4
#define IDS_SERVER_DEFAULT              5
#define IDS_SNAPINNAME                  6
#define IDS_PROGRAM_DEFAULT             7
#define IDS_ABOUTNAME                   9
#define IDD_PROPPAGE_LARGE              10
#define IDS_PST_TAB_NAME                10
#define IDD_PROPPAGE_DIRECTIVE          10
#define IDD_PROPPAGE                    10
#define IDI_ICON1                       108
#define IDI_PSI_ROCKET                  114
#define IDR_SMICONS                     120
#define IDR_LGICONS                     121
#define IDB_SMOPEN                      124
#define IDB_SMBMP                       125
#define IDB_LGBMP                       126
#define IDC_PROPS                       1006
#define IDC_EDIT2                       1008
#define IDC_COMBO3                      1009
#define IDC_ValueBox                    1009
#define IDC_ValueEdit                   1014
#define IDC_InheritedFrom               1015
#define IDC_InheritedFrombak            1015
#define IDC_MoreInfo                    1016
#define IDC_NAME                        1018
#define IDC_InheritedFromStatic         1019
#define IDC_Delete                      1020
#define IDC_Refresh                     1021
#define IDC_EDIT1                       1023
#define IDB_ROCKET                      40004
#define IDB_CAR                         40005
#define IDB_PLANE                       40006
#define IDB_BIKE                        40007
#define IDB_ROCKET2                     40008
#define IDB_CAR2                        40009
#define IDB_PLANE2                      40010
#define IDB_BIKE2                       40011
#define IDB_CLOSED2                     40012
#define IDB_OPEN2                       40013
#define IDB_CLOSED                      40014
#define IDB_OPEN                        40015
#define ID_BUTTON40016                  40016
#define ID_BUTTON40017                  40017
#define ID_BUTTON40018                  40018
#define ID_BUTTON40019                  40019
#define ID_BUTTON40020                  40020
#define ID_BUTTON40021                  40021
#define ID_BUTTON40022                  40022
#define ID_BUTTON40023                  40023
#define ID_BUTTON40024                  40024
#define ID_BUTTON40025                  40025
#define ID_BUTTON40026                  40026
#define EDIT1                           40027
#define EDIT2                           40028
#define EDIT3                           40029
#define EDIT4                           40030
#define COMBO1                          40031

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40032
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
